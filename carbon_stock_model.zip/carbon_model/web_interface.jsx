import React, { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, AreaChart, Area } from 'recharts';

// Indian Species Database (simplified for web)
const SPECIES_DATABASE = {
  "Tectona grandis": { common: "Teak", Hm: 35, rho: 550, k: 0.06, Dmax: 0.9, zeta: 0.21, bef: 1.46 },
  "Eucalyptus tereticornis": { common: "Eucalyptus", Hm: 45, rho: 640, k: 0.15, Dmax: 0.7, zeta: 0.17, bef: 1.31 },
  "Populus deltoides": { common: "Poplar", Hm: 30, rho: 380, k: 0.18, Dmax: 0.6, zeta: 0.20, bef: 1.35 },
  "Dalbergia sissoo": { common: "Shisham", Hm: 25, rho: 770, k: 0.07, Dmax: 0.8, zeta: 0.33, bef: 1.70 },
  "Azadirachta indica": { common: "Neem", Hm: 20, rho: 690, k: 0.08, Dmax: 0.6, zeta: 0.25, bef: 1.45 },
  "Shorea robusta": { common: "Sal", Hm: 35, rho: 720, k: 0.05, Dmax: 1.0, zeta: 0.27, bef: 1.30 },
  "Acacia auriculiformis": { common: "Acacia", Hm: 25, rho: 550, k: 0.13, Dmax: 0.5, zeta: 0.24, bef: 1.32 },
  "Casuarina equisetifolia": { common: "Casuarina", Hm: 25, rho: 830, k: 0.12, Dmax: 0.45, zeta: 0.22, bef: 1.25 },
  "Mangifera indica": { common: "Mango", Hm: 25, rho: 550, k: 0.07, Dmax: 0.8, zeta: 0.29, bef: 1.55 },
  "Gmelina arborea": { common: "Gamhar", Hm: 30, rho: 430, k: 0.12, Dmax: 0.7, zeta: 0.22, bef: 1.38 },
};

// Model calculations
const calculateProjection = (species, quantity, years = 40) => {
  const traits = SPECIES_DATABASE[species];
  if (!traits) return [];
  
  const results = [];
  const baseModality = 0.02;
  const rhoRef = 600;
  const mortalityMod = Math.sqrt(rhoRef / traits.rho);
  const annualMortality = baseModality * mortalityMod;
  const formFactor = 0.42;
  const carbonFraction = 0.47;
  
  for (let year = 1; year <= years; year++) {
    // Diameter (Chapman-Richards)
    const D = traits.Dmax * Math.pow(1 - Math.exp(-traits.k * year), 1.3);
    
    // Height (T-model)
    const H = Math.max(1.3, traits.Hm * (1 - Math.exp(-50 * D / traits.Hm)));
    
    // Survival
    const survival = Math.max(0.1, Math.exp(-annualMortality * year));
    const survivingTrees = Math.floor(quantity * survival);
    
    // Volume and biomass
    const volume = (Math.PI / 4) * D * D * H * formFactor;
    const agbVolume = volume * traits.rho * traits.bef;
    
    // Chave equation
    const Dcm = D * 100;
    const agbChave = 0.0673 * Math.pow((traits.rho/1000) * Dcm * Dcm * H, 0.976);
    
    const agbPerTree = (agbVolume + agbChave) / 2;
    const bgbPerTree = agbPerTree * traits.zeta;
    
    const totalAgb = agbPerTree * survivingTrees / 1000;
    const totalBgb = bgbPerTree * survivingTrees / 1000;
    const totalCarbon = (totalAgb + totalBgb) * carbonFraction;
    const co2eq = totalCarbon * 3.67;
    
    results.push({
      year,
      dbh: (D * 100).toFixed(1),
      height: H.toFixed(1),
      survival: (survival * 100).toFixed(1),
      survivingTrees,
      agb: totalAgb.toFixed(1),
      bgb: totalBgb.toFixed(1),
      carbon: totalCarbon.toFixed(1),
      co2: co2eq.toFixed(1),
    });
  }
  
  return results;
};

export default function CarbonStockModel() {
  const [species, setSpecies] = useState("Tectona grandis");
  const [quantity, setQuantity] = useState(1000);
  const [years, setYears] = useState(40);
  const [view, setView] = useState('carbon');
  
  const projection = useMemo(() => 
    calculateProjection(species, quantity, years),
    [species, quantity, years]
  );
  
  const finalYear = projection[projection.length - 1];
  const traits = SPECIES_DATABASE[species];
  
  const chartData = projection.map(p => ({
    ...p,
    agb: parseFloat(p.agb),
    bgb: parseFloat(p.bgb),
    carbon: parseFloat(p.carbon),
    co2: parseFloat(p.co2),
    dbh: parseFloat(p.dbh),
    height: parseFloat(p.height),
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-green-800 mb-2">🌳 Carbon Stock Assessment Model</h1>
          <p className="text-green-600">Project AGB + BGB for Indian Tree Plantations (40 years)</p>
        </div>
        
        {/* Input Controls */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Species</label>
              <select 
                value={species}
                onChange={(e) => setSpecies(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
              >
                {Object.entries(SPECIES_DATABASE).map(([sci, data]) => (
                  <option key={sci} value={sci}>{data.common} ({sci})</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Number of Trees</label>
              <input 
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                min="1"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Projection Years</label>
              <input 
                type="number"
                value={years}
                onChange={(e) => setYears(Math.min(100, Math.max(1, parseInt(e.target.value) || 40)))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                min="1"
                max="100"
              />
            </div>
          </div>
          
          {/* Species Info */}
          {traits && (
            <div className="mt-4 p-4 bg-green-50 rounded-lg">
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4 text-sm">
                <div><span className="text-gray-500">Max Height:</span> <span className="font-semibold">{traits.Hm}m</span></div>
                <div><span className="text-gray-500">Wood Density:</span> <span className="font-semibold">{traits.rho} kg/m³</span></div>
                <div><span className="text-gray-500">Growth Rate:</span> <span className="font-semibold">{traits.k}</span></div>
                <div><span className="text-gray-500">Max DBH:</span> <span className="font-semibold">{traits.Dmax * 100}cm</span></div>
                <div><span className="text-gray-500">Root:Shoot:</span> <span className="font-semibold">{traits.zeta}</span></div>
                <div><span className="text-gray-500">BEF:</span> <span className="font-semibold">{traits.bef}</span></div>
              </div>
            </div>
          )}
        </div>
        
        {/* Summary Cards */}
        {finalYear && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-xl shadow p-4 text-center">
              <div className="text-3xl font-bold text-green-600">{finalYear.carbon}</div>
              <div className="text-sm text-gray-500">Tonnes Carbon</div>
            </div>
            <div className="bg-white rounded-xl shadow p-4 text-center">
              <div className="text-3xl font-bold text-blue-600">{finalYear.co2}</div>
              <div className="text-sm text-gray-500">Tonnes CO₂eq</div>
            </div>
            <div className="bg-white rounded-xl shadow p-4 text-center">
              <div className="text-3xl font-bold text-amber-600">{parseFloat(finalYear.agb) + parseFloat(finalYear.bgb)}</div>
              <div className="text-sm text-gray-500">Tonnes Biomass</div>
            </div>
            <div className="bg-white rounded-xl shadow p-4 text-center">
              <div className="text-3xl font-bold text-emerald-600">{finalYear.survivingTrees.toLocaleString()}</div>
              <div className="text-sm text-gray-500">Surviving Trees</div>
            </div>
          </div>
        )}
        
        {/* Chart Selection */}
        <div className="flex gap-2 mb-4 flex-wrap">
          {['carbon', 'biomass', 'growth', 'co2'].map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                view === v 
                  ? 'bg-green-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-green-100'
              }`}
            >
              {v === 'carbon' && '🌿 Carbon Stock'}
              {v === 'biomass' && '🪵 Biomass (AGB+BGB)'}
              {v === 'growth' && '📏 Tree Growth'}
              {v === 'co2' && '💨 CO₂ Equivalent'}
            </button>
          ))}
        </div>
        
        {/* Charts */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <ResponsiveContainer width="100%" height={400}>
            {view === 'carbon' && (
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" label={{ value: 'Year', position: 'bottom' }} />
                <YAxis label={{ value: 'Carbon (tonnes)', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="carbon" stroke="#16a34a" strokeWidth={3} name="Total Carbon (t C)" />
              </LineChart>
            )}
            
            {view === 'biomass' && (
              <AreaChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis label={{ value: 'Biomass (tonnes)', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="bgb" stackId="1" stroke="#8B4513" fill="#8B4513" name="BGB" />
                <Area type="monotone" dataKey="agb" stackId="1" stroke="#228B22" fill="#228B22" name="AGB" />
              </AreaChart>
            )}
            
            {view === 'growth' && (
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis yAxisId="left" label={{ value: 'DBH (cm)', angle: -90, position: 'insideLeft' }} />
                <YAxis yAxisId="right" orientation="right" label={{ value: 'Height (m)', angle: 90, position: 'insideRight' }} />
                <Tooltip />
                <Legend />
                <Line yAxisId="left" type="monotone" dataKey="dbh" stroke="#3b82f6" strokeWidth={2} name="DBH (cm)" />
                <Line yAxisId="right" type="monotone" dataKey="height" stroke="#22c55e" strokeWidth={2} name="Height (m)" />
              </LineChart>
            )}
            
            {view === 'co2' && (
              <AreaChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis label={{ value: 'CO₂ Equivalent (tonnes)', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="co2" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.3} name="CO₂ eq (tonnes)" />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
        
        {/* Data Table */}
        <div className="bg-white rounded-xl shadow-lg p-6 overflow-x-auto">
          <h3 className="text-lg font-semibold mb-4">Projection Data (Key Years)</h3>
          <table className="w-full text-sm">
            <thead className="bg-green-50">
              <tr>
                <th className="p-2 text-left">Year</th>
                <th className="p-2 text-right">DBH (cm)</th>
                <th className="p-2 text-right">Height (m)</th>
                <th className="p-2 text-right">Survival</th>
                <th className="p-2 text-right">AGB (t)</th>
                <th className="p-2 text-right">BGB (t)</th>
                <th className="p-2 text-right">Carbon (t)</th>
                <th className="p-2 text-right">CO₂eq (t)</th>
              </tr>
            </thead>
            <tbody>
              {projection.filter((_, i) => [0, 4, 9, 14, 19, 29, 39].includes(i) || i === projection.length - 1).map((row) => (
                <tr key={row.year} className="border-b hover:bg-green-50">
                  <td className="p-2 font-medium">{row.year}</td>
                  <td className="p-2 text-right">{row.dbh}</td>
                  <td className="p-2 text-right">{row.height}</td>
                  <td className="p-2 text-right">{row.survival}%</td>
                  <td className="p-2 text-right">{row.agb}</td>
                  <td className="p-2 text-right">{row.bgb}</td>
                  <td className="p-2 text-right font-semibold text-green-600">{row.carbon}</td>
                  <td className="p-2 text-right font-semibold text-blue-600">{row.co2}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Footer */}
        <div className="text-center mt-6 text-sm text-gray-500">
          <p>Based on T-model (Plant-FATE) & Chapman-Richards growth equations</p>
          <p>Species data from FSI, ICFRE & Indian forestry research</p>
        </div>
      </div>
    </div>
  );
}
