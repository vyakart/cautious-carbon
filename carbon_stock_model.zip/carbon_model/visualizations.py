"""
Carbon Stock Model - Visualization Module
==========================================

Generate charts and visualizations for carbon stock projections.

Author: Medius Earth
"""

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Tuple

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 11
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12


def plot_carbon_trajectory(
    df: pd.DataFrame,
    species_name: str,
    quantity: int,
    save_path: Optional[str] = None,
    show: bool = True
) -> plt.Figure:
    """
    Plot carbon stock trajectory over time for a single species.
    
    Args:
        df: Projection DataFrame from model
        species_name: Name of species
        quantity: Initial quantity planted
        save_path: Path to save figure (optional)
        show: Whether to display the plot
        
    Returns:
        matplotlib Figure object
    """
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle(f'Carbon Stock Projection: {species_name}\n({quantity:,} trees planted)', 
                 fontsize=16, fontweight='bold')
    
    years = df['year']
    
    # Plot 1: Biomass over time
    ax1 = axes[0, 0]
    ax1.fill_between(years, 0, df['total_bgb_tonnes'], alpha=0.7, label='BGB', color='#8B4513')
    ax1.fill_between(years, df['total_bgb_tonnes'], 
                     df['total_bgb_tonnes'] + df['total_agb_tonnes'], 
                     alpha=0.7, label='AGB', color='#228B22')
    ax1.set_xlabel('Year')
    ax1.set_ylabel('Biomass (tonnes)')
    ax1.set_title('Total Biomass Accumulation')
    ax1.legend(loc='upper left')
    ax1.set_xlim(1, years.max())
    
    # Plot 2: Carbon and CO2 equivalent
    ax2 = axes[0, 1]
    ax2.plot(years, df['total_carbon_tonnes'], 'g-', linewidth=2, label='Carbon (t C)')
    ax2.plot(years, df['co2_equivalent_tonnes'], 'b--', linewidth=2, label='CO₂ equivalent (t CO₂)')
    ax2.set_xlabel('Year')
    ax2.set_ylabel('Stock (tonnes)')
    ax2.set_title('Carbon Stock and CO₂ Equivalent')
    ax2.legend(loc='upper left')
    ax2.set_xlim(1, years.max())
    
    # Plot 3: Tree dimensions
    ax3 = axes[1, 0]
    ax3_twin = ax3.twinx()
    
    line1, = ax3.plot(years, df['dbh_cm'], 'b-', linewidth=2, label='DBH')
    line2, = ax3_twin.plot(years, df['height_m'], 'g-', linewidth=2, label='Height')
    
    ax3.set_xlabel('Year')
    ax3.set_ylabel('DBH (cm)', color='b')
    ax3_twin.set_ylabel('Height (m)', color='g')
    ax3.set_title('Tree Growth (DBH and Height)')
    ax3.tick_params(axis='y', labelcolor='b')
    ax3_twin.tick_params(axis='y', labelcolor='g')
    
    lines = [line1, line2]
    labels = [l.get_label() for l in lines]
    ax3.legend(lines, labels, loc='upper left')
    ax3.set_xlim(1, years.max())
    
    # Plot 4: Survival and per-tree biomass
    ax4 = axes[1, 1]
    ax4_twin = ax4.twinx()
    
    line1, = ax4.plot(years, df['survival_rate'] * 100, 'r-', linewidth=2, label='Survival Rate')
    per_tree_biomass = df['agb_kg_per_tree'] + df['bgb_kg_per_tree']
    line2, = ax4_twin.plot(years, per_tree_biomass, 'purple', linewidth=2, label='Biomass/tree')
    
    ax4.set_xlabel('Year')
    ax4.set_ylabel('Survival Rate (%)', color='r')
    ax4_twin.set_ylabel('Biomass per tree (kg)', color='purple')
    ax4.set_title('Survival Rate and Per-Tree Biomass')
    ax4.tick_params(axis='y', labelcolor='r')
    ax4_twin.tick_params(axis='y', labelcolor='purple')
    ax4.set_ylim(0, 105)
    
    lines = [line1, line2]
    labels = [l.get_label() for l in lines]
    ax4.legend(lines, labels, loc='right')
    ax4.set_xlim(1, years.max())
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    
    if show:
        plt.show()
    
    return fig


def plot_species_comparison(
    model,
    species_list: List[str],
    quantity: int = 1000,
    years: int = 40,
    save_path: Optional[str] = None,
    show: bool = True
) -> plt.Figure:
    """
    Compare carbon sequestration across multiple species.
    
    Args:
        model: CarbonStockModel instance
        species_list: List of species names to compare
        quantity: Number of trees for each species
        years: Projection years
        save_path: Path to save figure
        show: Whether to display
        
    Returns:
        matplotlib Figure object
    """
    from carbon_stock_model import CarbonStockModel
    from datetime import datetime
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle(f'Species Comparison: Carbon Sequestration\n({quantity:,} trees each)', 
                 fontsize=16, fontweight='bold')
    
    colors = plt.cm.tab10(np.linspace(0, 1, len(species_list)))
    
    projections = {}
    for species in species_list:
        try:
            df = model.project_single_species(
                species_name=species,
                quantity=quantity,
                planting_date=datetime(2025, 1, 1),
                years=years
            )
            projections[species] = df
        except ValueError as e:
            print(f"Warning: {e}")
    
    # Plot 1: Total Carbon over time
    ax1 = axes[0, 0]
    for (species, df), color in zip(projections.items(), colors):
        common_name = model.species_db[species].common_name
        ax1.plot(df['year'], df['total_carbon_tonnes'], 
                label=common_name, linewidth=2, color=color)
    ax1.set_xlabel('Year')
    ax1.set_ylabel('Carbon Stock (tonnes C)')
    ax1.set_title('Total Carbon Accumulation')
    ax1.legend(loc='upper left', fontsize=9)
    ax1.set_xlim(1, years)
    
    # Plot 2: CO2 Equivalent
    ax2 = axes[0, 1]
    for (species, df), color in zip(projections.items(), colors):
        common_name = model.species_db[species].common_name
        ax2.plot(df['year'], df['co2_equivalent_tonnes'], 
                label=common_name, linewidth=2, color=color)
    ax2.set_xlabel('Year')
    ax2.set_ylabel('CO₂ Equivalent (tonnes)')
    ax2.set_title('CO₂ Sequestration')
    ax2.legend(loc='upper left', fontsize=9)
    ax2.set_xlim(1, years)
    
    # Plot 3: Final carbon at year 40 (bar chart)
    ax3 = axes[1, 0]
    final_carbon = []
    labels = []
    for species, df in projections.items():
        final_carbon.append(df.iloc[-1]['total_carbon_tonnes'])
        labels.append(model.species_db[species].common_name)
    
    bars = ax3.barh(labels, final_carbon, color=colors[:len(labels)])
    ax3.set_xlabel('Carbon Stock at Year 40 (tonnes C)')
    ax3.set_title('Final Carbon Stock Comparison')
    
    # Add value labels
    for bar, val in zip(bars, final_carbon):
        ax3.text(val + 1, bar.get_y() + bar.get_height()/2, 
                f'{val:.0f}t', va='center', fontsize=9)
    
    # Plot 4: Biomass per tree comparison
    ax4 = axes[1, 1]
    for (species, df), color in zip(projections.items(), colors):
        common_name = model.species_db[species].common_name
        per_tree = df['agb_kg_per_tree'] + df['bgb_kg_per_tree']
        ax4.plot(df['year'], per_tree, label=common_name, linewidth=2, color=color)
    ax4.set_xlabel('Year')
    ax4.set_ylabel('Biomass per Tree (kg)')
    ax4.set_title('Individual Tree Biomass Growth')
    ax4.legend(loc='upper left', fontsize=9)
    ax4.set_xlim(1, years)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    
    if show:
        plt.show()
    
    return fig


def plot_mixed_planting_summary(
    summary_df: pd.DataFrame,
    detailed_df: pd.DataFrame,
    save_path: Optional[str] = None,
    show: bool = True
) -> plt.Figure:
    """
    Plot summary for mixed species plantings.
    
    Args:
        summary_df: Summary DataFrame with totals by year
        detailed_df: Detailed DataFrame with per-species data
        save_path: Path to save figure
        show: Whether to display
        
    Returns:
        matplotlib Figure object
    """
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Mixed Planting Carbon Stock Projection', fontsize=16, fontweight='bold')
    
    years = summary_df['year']
    
    # Plot 1: Stacked area by species (carbon)
    ax1 = axes[0, 0]
    species_list = detailed_df['species'].unique()
    colors = plt.cm.tab10(np.linspace(0, 1, len(species_list)))
    
    bottom = np.zeros(len(years))
    for species, color in zip(species_list, colors):
        sp_data = detailed_df[detailed_df['species'] == species].sort_values('year')
        carbon = sp_data['total_carbon_tonnes'].values
        ax1.fill_between(years, bottom, bottom + carbon, label=species, alpha=0.7, color=color)
        bottom += carbon
    
    ax1.set_xlabel('Year')
    ax1.set_ylabel('Carbon Stock (tonnes C)')
    ax1.set_title('Carbon Stock by Species')
    ax1.legend(loc='upper left', fontsize=8)
    ax1.set_xlim(1, years.max())
    
    # Plot 2: Total biomass (AGB + BGB)
    ax2 = axes[0, 1]
    ax2.fill_between(years, 0, summary_df['total_bgb_tonnes'], 
                     alpha=0.7, label='BGB', color='#8B4513')
    ax2.fill_between(years, summary_df['total_bgb_tonnes'], 
                     summary_df['total_biomass_tonnes'], 
                     alpha=0.7, label='AGB', color='#228B22')
    ax2.set_xlabel('Year')
    ax2.set_ylabel('Biomass (tonnes)')
    ax2.set_title('Total Biomass (AGB + BGB)')
    ax2.legend(loc='upper left')
    ax2.set_xlim(1, years.max())
    
    # Plot 3: CO2 equivalent over time
    ax3 = axes[1, 0]
    ax3.plot(years, summary_df['co2_equivalent_tonnes'], 'b-', linewidth=2)
    ax3.fill_between(years, 0, summary_df['co2_equivalent_tonnes'], alpha=0.3)
    ax3.set_xlabel('Year')
    ax3.set_ylabel('CO₂ Equivalent (tonnes)')
    ax3.set_title('Total CO₂ Sequestration')
    ax3.set_xlim(1, years.max())
    
    # Add annotations for key milestones
    for year in [10, 20, 30, 40]:
        if year <= years.max():
            val = summary_df[summary_df['year'] == year]['co2_equivalent_tonnes'].values[0]
            ax3.annotate(f'{val:.0f}t', xy=(year, val), 
                        xytext=(year, val + val*0.1),
                        fontsize=9, ha='center')
    
    # Plot 4: Surviving trees
    ax4 = axes[1, 1]
    ax4.plot(years, summary_df['surviving_trees'], 'g-', linewidth=2)
    ax4.fill_between(years, 0, summary_df['surviving_trees'], alpha=0.3, color='green')
    ax4.set_xlabel('Year')
    ax4.set_ylabel('Number of Trees')
    ax4.set_title('Total Surviving Trees')
    ax4.yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, p: format(int(x), ',')))
    ax4.set_xlim(1, years.max())
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    
    if show:
        plt.show()
    
    return fig


def generate_report_charts(
    model,
    plantings_csv: str,
    output_dir: str = "charts",
    years: int = 40
):
    """
    Generate a complete set of charts for a planting project.
    
    Args:
        model: CarbonStockModel instance
        plantings_csv: Path to plantings CSV file
        output_dir: Directory to save charts
        years: Projection years
    """
    from carbon_stock_model import load_plantings_from_csv
    
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    # Load plantings
    plantings = load_plantings_from_csv(plantings_csv)
    
    # Get projections
    summary_df, detailed_df = model.project_mixed_planting(plantings, years)
    
    # Generate mixed planting summary
    plot_mixed_planting_summary(
        summary_df, detailed_df,
        save_path=str(output_path / "01_project_summary.png"),
        show=False
    )
    
    # Generate individual species charts
    for i, planting in enumerate(plantings, 1):
        df = model.project_single_species(
            planting.species_name,
            planting.quantity,
            planting.planting_date,
            years
        )
        plot_carbon_trajectory(
            df, planting.species_name, planting.quantity,
            save_path=str(output_path / f"{i+1:02d}_{planting.species_name.replace(' ', '_')}.png"),
            show=False
        )
    
    # Species comparison
    species_list = list(set(p.species_name for p in plantings))
    plot_species_comparison(
        model, species_list,
        save_path=str(output_path / "00_species_comparison.png"),
        show=False
    )
    
    print(f"\nAll charts saved to {output_dir}/")


if __name__ == "__main__":
    from carbon_stock_model import CarbonStockModel
    
    model = CarbonStockModel()
    
    # Example: Generate comparison chart for common Indian plantation species
    species_to_compare = [
        "Tectona grandis",
        "Eucalyptus tereticornis",
        "Populus deltoides",
        "Dalbergia sissoo",
        "Azadirachta indica"
    ]
    
    print("Generating species comparison chart...")
    plot_species_comparison(model, species_to_compare, quantity=1000, years=40)
