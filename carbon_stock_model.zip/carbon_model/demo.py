#!/usr/bin/env python3
"""
Carbon Stock Model - Demonstration Script
==========================================

This script demonstrates all the capabilities of the carbon stock model.
Run this to see the model in action with sample data.

Usage:
    python demo.py

Author: Medius Earth
"""

import sys
from datetime import datetime
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from carbon_stock_model import (
    CarbonStockModel,
    PlantingRecord,
    SpeciesTraits,
    load_plantings_from_csv,
    print_species_info
)


def demo_single_species():
    """Demonstrate single species projection."""
    print("\n" + "="*80)
    print("DEMO 1: Single Species Projection")
    print("="*80)
    
    model = CarbonStockModel()
    
    # Project 1000 Teak trees
    results = model.project_single_species(
        species_name="Tectona grandis",
        quantity=1000,
        planting_date=datetime(2025, 1, 1),
        years=40
    )
    
    print("\n1000 Teak (Tectona grandis) trees planted on 2025-01-01")
    print("\nProjection Results:")
    print("-" * 95)
    print("Year | DBH(cm) | Height(m) | Surviving | AGB(t) | BGB(t) | Carbon(t) | CO2eq(t)")
    print("-" * 95)
    
    for year in [1, 5, 10, 15, 20, 30, 40]:
        row = results[results['year'] == year].iloc[0]
        print(f"{row['year']:4d} | {row['dbh_cm']:7.1f} | {row['height_m']:9.1f} | "
              f"{row['surviving_trees']:9,d} | {row['total_agb_tonnes']:6.1f} | "
              f"{row['total_bgb_tonnes']:6.1f} | {row['total_carbon_tonnes']:9.1f} | "
              f"{row['co2_equivalent_tonnes']:8.1f}")
    
    # Final summary
    final = results.iloc[-1]
    print("\n" + "-" * 95)
    print(f"TOTAL AT YEAR 40:")
    print(f"  • Total Biomass: {final['total_biomass_tonnes']:.1f} tonnes")
    print(f"  • Total Carbon: {final['total_carbon_tonnes']:.1f} tonnes C")
    print(f"  • CO2 Equivalent: {final['co2_equivalent_tonnes']:.1f} tonnes CO2")
    print(f"  • Carbon per tree: {final['total_carbon_tonnes']*1000/final['surviving_trees']:.1f} kg C")
    
    return results


def demo_multiple_species():
    """Demonstrate mixed species projection."""
    print("\n" + "="*80)
    print("DEMO 2: Mixed Species Plantation")
    print("="*80)
    
    model = CarbonStockModel()
    
    # Create sample plantings
    plantings = [
        PlantingRecord("Tectona grandis", 500, datetime(2025, 1, 15), "Maharashtra"),
        PlantingRecord("Eucalyptus tereticornis", 1000, datetime(2025, 1, 15), "Tamil Nadu"),
        PlantingRecord("Azadirachta indica", 300, datetime(2025, 2, 1), "Rajasthan"),
        PlantingRecord("Dalbergia sissoo", 200, datetime(2025, 1, 20), "Uttar Pradesh"),
        PlantingRecord("Populus deltoides", 800, datetime(2025, 2, 1), "Punjab"),
    ]
    
    print("\nPlanting Configuration:")
    print("-" * 60)
    total_trees = 0
    for p in plantings:
        common = model.species_db[p.species_name].common_name
        print(f"  {p.quantity:,} {common:20s} ({p.species_name}) - {p.location}")
        total_trees += p.quantity
    print("-" * 60)
    print(f"  TOTAL: {total_trees:,} trees")
    
    # Run projection
    summary_df, detailed_df = model.project_mixed_planting(plantings, years=40)
    
    print("\nCombined Projection Summary:")
    print("-" * 90)
    print("Year | Trees | AGB(t) | BGB(t) | Total(t) | Carbon(t) | CO2eq(t)")
    print("-" * 90)
    
    for year in [1, 5, 10, 20, 30, 40]:
        row = summary_df[summary_df['year'] == year].iloc[0]
        print(f"{year:4d} | {int(row['surviving_trees']):5,d} | {row['total_agb_tonnes']:6.1f} | "
              f"{row['total_bgb_tonnes']:6.1f} | {row['total_biomass_tonnes']:8.1f} | "
              f"{row['total_carbon_tonnes']:9.1f} | {row['co2_equivalent_tonnes']:8.1f}")
    
    # Species breakdown at year 40
    print("\n\nSpecies Breakdown at Year 40:")
    print("-" * 70)
    
    year_40 = detailed_df[detailed_df['year'] == 40]
    for _, row in year_40.iterrows():
        common = model.species_db[row['species']].common_name
        print(f"  {common:20s}: {row['total_carbon_tonnes']:6.1f} tonnes C | "
              f"{row['co2_equivalent_tonnes']:7.1f} tonnes CO2")
    
    return summary_df, detailed_df


def demo_species_comparison():
    """Compare carbon sequestration rates across species."""
    print("\n" + "="*80)
    print("DEMO 3: Species Comparison (Carbon Efficiency)")
    print("="*80)
    
    model = CarbonStockModel()
    
    # Compare common plantation species
    species_to_compare = [
        "Eucalyptus tereticornis",  # Fast growing
        "Populus deltoides",         # Very fast
        "Tectona grandis",           # Medium, high value
        "Dalbergia sissoo",          # Slow, high density
        "Bambusa bambos",            # Very fast, different form
        "Moringa oleifera",          # Very fast, small
    ]
    
    print("\nComparing 1000 trees of each species over 40 years:")
    print("-" * 90)
    print(f"{'Species':<30} | {'Year 10':>10} | {'Year 20':>10} | {'Year 40':>10} | {'Rate*':>10}")
    print("-" * 90)
    
    results = {}
    for species in species_to_compare:
        df = model.project_single_species(
            species_name=species,
            quantity=1000,
            planting_date=datetime(2025, 1, 1),
            years=40
        )
        results[species] = df
        
        common = model.species_db[species].common_name
        c10 = df[df['year'] == 10]['total_carbon_tonnes'].values[0]
        c20 = df[df['year'] == 20]['total_carbon_tonnes'].values[0]
        c40 = df[df['year'] == 40]['total_carbon_tonnes'].values[0]
        rate = c40 / 40  # Average annual sequestration
        
        print(f"{common:<30} | {c10:>8.1f} t | {c20:>8.1f} t | {c40:>8.1f} t | {rate:>7.2f} t/yr")
    
    print("-" * 90)
    print("* Average annual carbon sequestration rate over 40 years")
    
    # Find best performers
    final_carbon = {sp: df.iloc[-1]['total_carbon_tonnes'] for sp, df in results.items()}
    sorted_species = sorted(final_carbon.items(), key=lambda x: x[1], reverse=True)
    
    print("\nRanking by Total Carbon at Year 40:")
    for i, (sp, carbon) in enumerate(sorted_species, 1):
        common = model.species_db[sp].common_name
        print(f"  {i}. {common}: {carbon:.1f} tonnes C")
    
    return results


def demo_growth_curves():
    """Show growth curves for different species."""
    print("\n" + "="*80)
    print("DEMO 4: Growth Curves (DBH and Height)")
    print("="*80)
    
    model = CarbonStockModel()
    
    # Compare growth patterns
    species = ["Eucalyptus tereticornis", "Tectona grandis", "Shorea robusta"]
    
    print("\nGrowth comparison (DBH in cm, Height in m):")
    
    for sp in species:
        traits = model.species_db[sp]
        print(f"\n{traits.common_name} ({sp}):")
        print(f"  Max Height: {traits.Hm}m | Growth rate: {traits.k_growth} | Max DBH: {traits.D_max*100}cm")
        print("  Year:  ", end="")
        for y in [5, 10, 15, 20, 30, 40]:
            print(f" {y:>6}", end="")
        print()
        
        print("  DBH:   ", end="")
        for y in [5, 10, 15, 20, 30, 40]:
            d = model.diameter_at_age(y, traits)
            print(f" {d*100:>5.1f}cm", end="")
        print()
        
        print("  Height:", end="")
        for y in [5, 10, 15, 20, 30, 40]:
            d = model.diameter_at_age(y, traits)
            h = model.height_from_diameter(d, traits)
            print(f" {h:>5.1f}m", end="")
        print()


def demo_custom_species():
    """Demonstrate adding a custom species."""
    print("\n" + "="*80)
    print("DEMO 5: Adding Custom Species")
    print("="*80)
    
    model = CarbonStockModel()
    
    # Add a custom species
    custom_species = SpeciesTraits(
        species_name="Santalum album",
        common_name="Sandalwood",
        Hm=12.0,  # Max height 12m
        rho=920,  # Very high wood density
        a=35.0,
        c=280,
        zeta=0.30,  # High root allocation
        k_growth=0.03,  # Very slow growth
        D_max=0.4,  # Max 40cm DBH
        bef=1.50,
        rotation_age=30,
        forest_type="Tropical Dry"
    )
    
    # Add to model
    model.species_db["Santalum album"] = custom_species
    
    print("\nAdded custom species: Sandalwood (Santalum album)")
    print(f"  Max Height: {custom_species.Hm}m")
    print(f"  Wood Density: {custom_species.rho} kg/m³")
    print(f"  Growth Rate: {custom_species.k_growth} (slow)")
    
    # Project
    results = model.project_single_species(
        "Santalum album", 1000, datetime(2025, 1, 1), 40
    )
    
    print("\n1000 Sandalwood trees projection:")
    for year in [10, 20, 30, 40]:
        row = results[results['year'] == year].iloc[0]
        print(f"  Year {year}: DBH={row['dbh_cm']:.1f}cm, Height={row['height_m']:.1f}m, "
              f"Carbon={row['total_carbon_tonnes']:.1f}t")


def demo_csv_export():
    """Demonstrate CSV export functionality."""
    print("\n" + "="*80)
    print("DEMO 6: CSV Export")
    print("="*80)
    
    model = CarbonStockModel()
    
    # Single species export
    results = model.project_single_species(
        "Tectona grandis", 1000, datetime(2025, 1, 1), 40
    )
    
    output_file = "demo_teak_projection.csv"
    results.to_csv(output_file, index=False)
    print(f"\nExported single species projection to: {output_file}")
    print("\nCSV columns:")
    for col in results.columns:
        print(f"  - {col}")
    
    # Mixed planting export
    plantings = [
        PlantingRecord("Tectona grandis", 500, datetime(2025, 1, 1)),
        PlantingRecord("Eucalyptus tereticornis", 1000, datetime(2025, 1, 1)),
    ]
    
    summary_df, detailed_df = model.project_mixed_planting(plantings, 40)
    
    summary_df.to_csv("demo_summary.csv", index=False)
    detailed_df.to_csv("demo_detailed.csv", index=False)
    
    print(f"\nExported mixed planting results:")
    print(f"  - demo_summary.csv (aggregated by year)")
    print(f"  - demo_detailed.csv (by species and year)")


def run_all_demos():
    """Run all demonstration functions."""
    print("\n" + "#"*80)
    print("#" + " "*30 + "CARBON STOCK MODEL" + " "*30 + "#")
    print("#" + " "*25 + "DEMONSTRATION SUITE" + " "*34 + "#")
    print("#"*80)
    
    demo_single_species()
    demo_multiple_species()
    demo_species_comparison()
    demo_growth_curves()
    demo_custom_species()
    demo_csv_export()
    
    print("\n" + "="*80)
    print("DEMO COMPLETE")
    print("="*80)
    print("\nNext steps:")
    print("  1. Run: python run_model.py --interactive")
    print("  2. Edit sample_plantings.csv with your data")
    print("  3. Run: python run_model.py --csv sample_plantings.csv --output results.csv")
    print("  4. Generate charts: python -c \"from visualizations import *; ...\"")
    print("\nFor more information, see README.md")


if __name__ == "__main__":
    run_all_demos()
